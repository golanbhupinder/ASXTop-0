from django.shortcuts import render
from .models import Company

def top_companies(request):
    companies = Company.objects.filter(
        pe_ratio__gt=0,
        pe_ratio__lt=50,
        net_profit__gt=0
    ).order_by('-net_profit')[:50]
    return render(request, 'stocks/top_companies.html', {'companies': companies})
