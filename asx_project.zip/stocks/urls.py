from django.urls import path
from . import views

urlpatterns = [
    path('top-companies/', views.top_companies, name='top_companies'),
]
