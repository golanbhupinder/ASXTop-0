from django.db import models

class Company(models.Model):
    name = models.CharField(max_length=255)
    ticker = models.CharField(max_length=10)
    pe_ratio = models.FloatField()
    net_profit = models.FloatField()
    market_cap = models.FloatField()
    eps = models.FloatField()
    sector = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.name} ({self.ticker})"
